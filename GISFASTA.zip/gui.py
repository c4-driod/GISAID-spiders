__author__ = 'cquxiaoy'
from tkinter import *
import ctypes
import download_fasta_neo as dt
from threading import Thread


def _start():
    start_date_str, end_date_str = e1.get(), e2.get()
    dt.adpath = '进度'+ start_date_str + end_date_str +'.txt'

    print('启动')
    dt.if_terminate = False
    dt.sms_start_date = start_date_str
    dt.sms_end_date = end_date_str
    dt.start()
    if dt.if_done:
        dt.d.close()
    r.destroy()


def start():
    Thread(target=_start, daemon=True).start()
    b.config(text='已开始', state=DISABLED)


font = '微软雅黑 20'
ctypes.windll.shcore.SetProcessDpiAwareness(True)
r = Tk()
r.title('gisaid fasta数据爬虫')
Label(r, text='账号:', font=font).grid(row=0, column=0)
Label(r, text='密码:', font=font).grid(row=1, column=0)
en, ep = Entry(r, width=11, font=font), Entry(r, width=11, font=font)
en.grid(row=0, column=1, columnspan=2)
ep.grid(row=1, column=1, columnspan=2)

Label(r, text='Submission Date:', font=font).grid(row=2, columnspan=3)
Label(r, text='to', font=font).grid(row=3, column=1)
b = Button(r, text='开始', command=start, font=font, relief='solid')
b.grid(row=4, columnspan=3, sticky='we')

e1, e2 = Entry(r, width=11, font=font), Entry(r, width=11, font=font)
e1.grid(row=3, column=0)
e2.grid(row=3, column=2)
e1.insert(0, '2022-02-19')
e2.insert(0, '2022-02-20')
Label(r, text='日期仅支持范例的格式\n日期不变的话，程序能断点续下\n'
              '遇到网络错误需要手动重启\n有问题请加QQ1977649208', font='仿宋 14').grid(row=5, columnspan=3)

r.mainloop()

