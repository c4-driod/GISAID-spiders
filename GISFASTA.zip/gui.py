__author__ = 'cquxiaoy'
from tkinter import *
import ctypes
import download_fasta_new as dt
from selenium import webdriver
import time
from threading import Thread


def check():
    # 监测主程序的状态
    while True:
        if dt.signal:
            dt.signal = False
        else:
            dt.if_terminate = True
            print('长时间未响应，即将重启')
        time.sleep(3000)


def _start():
    start_date_str, end_date_str = e1.get(), e2.get()
    dt.adpath = '进度'+ start_date_str + end_date_str +'.txt'

    for i in range(100):
        print('第%d次启动'%(i+1))
        if dt.if_done:
            break
        elif dt.if_terminate:
            dt.d.close()
            dt.d = webdriver.Chrome()
        dt.if_terminate = False
        dt.sms_start_date = start_date_str
        dt.sms_end_date = end_date_str
        try:
            Thread(target=check, daemon=True).start()
            dt.start()
        except Exception as e:
            print('出错：', e)


def start():
    Thread(target=_start, daemon=True).start()
    r.withdraw()


font = 'weiruanyahei 20'
ctypes.windll.shcore.SetProcessDpiAwareness(True)
r = Tk()
r.title('gisaid fasta数据爬虫')
Label(r, text='账号:', font=font).grid(row=0, column=0)
Label(r, text='密码:', font=font).grid(row=1, column=0)
en, ep = Entry(r, width=11, font=font), Entry(r, width=11, font=font)
en.grid(row=0, column=1, columnspan=2)
ep.grid(row=1, column=1, columnspan=2)

Label(r, text='Submission Date:', font=font).grid(row=2, columnspan=3)
Label(r, text='to', font=font).grid(row=3, column=1)
Button(r, text='开始', command=start, font=font).grid(row=4, columnspan=3)

e1, e2 = Entry(r, width=11, font=font), Entry(r, width=11, font=font)
e1.grid(row=3, column=0)
e2.grid(row=3, column=2)
e1.insert(0, '2022-02-19')
e2.insert(0, '2022-02-20')
Label(r, text='日期仅支持范例的格式\n日期不变的话，程序能断点续下\n有问题请加QQ1977649208', font='weiruanyahei 16').grid(row=5, columnspan=3)

r.mainloop()

